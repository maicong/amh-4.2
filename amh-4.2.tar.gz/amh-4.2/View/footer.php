<?php !defined('_Amysql') && exit; ?>

<div id="footer">
AMH <?php echo $_SESSION['amh_version'];?> [LNMP] Powered by <a href="http://amysql.com/" target="_blank">amysql.com</a> <br />
©2013 专注于LNMP / Nginx 平台架构开发
</div>
</body>
</html>